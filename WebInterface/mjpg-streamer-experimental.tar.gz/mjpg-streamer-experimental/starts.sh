screen -S webcam ./mjpg_streamer -o "output_http.so -w ./www" -i "input_uvc.so"
